var paddle,paddleImage
var ball,ballImage
var score
var gameState
var PLAY
var END
var score

function preload() {
paddleImage=loadImage("paddle.png")
ballImage=loadImage("ball.png")
  
}
function setup() {
  createCanvas(400, 400);
  paddle=createSprite(350,200,20,20)
  paddle.addImage ("playing",paddleImage)
  gameState=PLAY;
  PLAY=1;
  END=0;
  score=0;
}

function draw() {
  background(205,153,0);
  createEdgeSprites();
  ball();
  

  
  
  if(keyDown(UP_ARROW)) 
    {
    paddle.velocityY=-5;
  }
  
  if(keyDown(DOWN_ARROW))
    {
     paddle.velocityY=5;
  }
 
   
  edges=createEdgeSprites();
  paddle.bounceOff(edges[2]);
  

  edges=createEdgeSprites();
  paddle.bounceOff(edges[3]);
  
   //scoring
    score =score+ Math.round(World.frameRate/55);
     if(gameState === PLAY){
       //scoring
    score =score+ Math.round(World.frameRate/55);
     }
  
  
  
  
  
  
  
  
  
  
  drawSprites();
  

}

function ball(){
  //write code here to spawn the ball
  if (frameCount % 80 === 0) {
    var ball = createSprite(90,200,20,20);
    ball.y = Math.round(random(80,180));
    ball.addImage(ballImage);
    ball.scale = 0.05;
    ball.velocityX=5
     
    ball.addImage ("running", ballImage)
  ball.scale=0.8;
    
     edges=createEdgeSprites();
  ball.bounceOff(edges[0]);
  
  edges=createEdgeSprites();
  ball.bounceOff(edges[3]);
  
  edges=createEdgeSprites();
  ball.bounceOff(edges[2]);
  
  
  edges=createEdgeSprites();
  ball.bounceOff(paddle);
   
    
  }     
}